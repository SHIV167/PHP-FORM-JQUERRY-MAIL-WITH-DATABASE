-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS consultation_db;

-- Use the newly created database
USE consultation_db;

-- Create the consultations table
CREATE TABLE IF NOT EXISTS consultations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fname VARCHAR(50) NOT NULL,
    lname VARCHAR(50) NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    email VARCHAR(100),
    weight DECIMAL(5,2) NOT NULL,
    height DECIMAL(5,2) NOT NULL,
    age INT NOT NULL,
    healthissues ENUM('diabetes', 'bp', 'thyroid', 'energy', 'enemy', 'weightloss') NOT NULL,
    sugar VARCHAR(50),
    bloodpressure SET('highbp', 'lowbp'),
    thyroid SET('hyper', 'hypo'),
    energy SET('last', 'ed'),
    enemy SET('inpiles', 'expiles'),
    weightgoal DECIMAL(5,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add indexes for better query performance
CREATE INDEX idx_healthissues ON consultations(healthissues);
CREATE INDEX idx_email ON consultations(email);
CREATE INDEX idx_mobile ON consultations(mobile);