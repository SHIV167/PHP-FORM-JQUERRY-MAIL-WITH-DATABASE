<?php
// process_form.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection details
$host = 'localhost';
$dbname = 'consultation';
$username = 'root';
$password = '';

// Establish database connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Could not connect to the database $dbname :" . $e->getMessage());
}

// Function to sanitize input
function sanitize_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Include PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './PHPMailer/src/Exception.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';

// Function to send email
function sendEmail($to, $subject, $body) {
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'jhashiv5@gmail.com'; // Use environment variable for security
        $mail->Password   = 'xtrq dljl pxoh ziqu'; // Use environment variable for security
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Recipients
        $mail->setFrom('jhashiv5@gmail.com', 'Web Impressions');
        $mail->addAddress($to);

        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

// Process form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and collect form data
    $fname = sanitize_input($_POST['fname']);
    $lname = sanitize_input($_POST['lname']);
    $mobile = sanitize_input($_POST['mobile']);
    $email = sanitize_input($_POST['email']);
    $weight = sanitize_input($_POST['weight']);
    $height = sanitize_input($_POST['height']);
    $age = sanitize_input($_POST['age']);
    $healthissues = sanitize_input($_POST['healthissues']);

    $sugar = isset($_POST['sugar']) ? sanitize_input($_POST['sugar']) : null;
    $bloodpressure = isset($_POST['bloodpressure1']) ? implode(',', $_POST['bloodpressure1']) : null;
    $thyroid = isset($_POST['thyroid1']) ? implode(',', $_POST['thyroid1']) : null;
    $energy = isset($_POST['energy1']) ? implode(',', $_POST['energy1']) : null;
    $enemy = isset($_POST['enemy1']) ? implode(',', $_POST['enemy1']) : null;
    $weightgoal = isset($_POST['weightgoal']) ? sanitize_input($_POST['weightgoal']) : null;

    // Prepare SQL statement
    $sql = "INSERT INTO consultations (fname, lname, mobile, email, weight, height, age, healthissues, sugar, bloodpressure, thyroid, energy, enemy, weightgoal) 
            VALUES (:fname, :lname, :mobile, :email, :weight, :height, :age, :healthissues, :sugar, :bloodpressure, :thyroid, :energy, :enemy, :weightgoal)";

    try {
        // Execute database insertion
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':fname' => $fname,
            ':lname' => $lname,
            ':mobile' => $mobile,
            ':email' => $email,
            ':weight' => $weight,
            ':height' => $height,
            ':age' => $age,
            ':healthissues' => $healthissues,
            ':sugar' => $sugar,
            ':bloodpressure' => $bloodpressure,
            ':thyroid' => $thyroid,
            ':energy' => $energy,
            ':enemy' => $enemy,
            ':weightgoal' => $weightgoal
        ]);

        // Prepare email content for user
        $userSubject = "Thank you for your consultation request";
        $userBody = "
        <html>
        <body>
            <h2>Thank you for your consultation request, $fname!</h2>
            <p>We have received your information and will contact you shortly.</p>
        </body>
        </html>";

        // Prepare email content for admin
        $adminSubject = "New Consultation Request";
        $adminBody = "
        <html>
        <body>
            <h2>New Consultation Request</h2>
            <p>Name: $fname $lname</p>
            <p>Email: $email</p>
            <p>Phone: $mobile</p>
            <p>Weight: $weight kg</p>
            <p>Height: $height cm</p>
            <p>Age: $age</p>
            <p>Health Issues: $healthissues</p>
        </body>
        </html>";

        $response = [
            'status' => 'success',
            'message' => 'Form submitted successfully!',
            'userEmailSent' => false,
            'adminEmailSent' => false
        ];

        // Send email to user
        if (sendEmail($email, $userSubject, $userBody)) {
            $response['userEmailSent'] = true;
        }

        // Send email to admin
        $adminEmail = 'jhashiv5@gmail.com'; // Replace with actual admin email
        if (sendEmail($adminEmail, $adminSubject, $adminBody)) {
            $response['adminEmailSent'] = true;
        }

        echo json_encode($response);
    } catch(PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    // If not a POST request, return an error
    header('HTTP/1.1 405 Method Not Allowed');
    header('Allow: POST');
    exit;
}
?>
